/*
buildnum.h
*/
#ifndef __BUILDNUM_H__
#define __BUILDNUM_H__ 1
#ifdef  __cplusplus
extern "C" {
#endif

#ifndef SCRIPTBASIC_BUILD
#define SCRIPTBASIC_BUILD 1
#endif
#ifdef __cplusplus
}
#endif
#endif
