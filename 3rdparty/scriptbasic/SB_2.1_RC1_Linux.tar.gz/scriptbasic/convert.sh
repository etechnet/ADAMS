chmod -R u+rw * ; cp -pf convert.pl ..; perl uncr convert.pl > temp; mv temp convert.pl; perl convert.pl;echo
