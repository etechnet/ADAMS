Objective:
    This is a simple example to show the usage of a variety corbaloc initial references.

How to Run:
    Compile:
        ant

    Run Server:
        jaco demo.corbaloc.Server

    Run Client:
        jaco demo.corbaloc.Client <corbaloc>
